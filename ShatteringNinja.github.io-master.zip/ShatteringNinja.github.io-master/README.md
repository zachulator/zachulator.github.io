When using this file to make your own website, please do the following;
Properly credit me, ShatteringNinja
Have authorization by me, or have paid patreonage.
If you do not have the following, just trust me, you will wish you did.
